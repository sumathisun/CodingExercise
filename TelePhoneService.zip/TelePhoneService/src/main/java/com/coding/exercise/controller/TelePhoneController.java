package com.coding.exercise.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.coding.exercise.model.GetResponse;
import com.coding.exercise.service.PhoneNumberService;

@RestController
public class TelePhoneController {
	@Autowired
	PhoneNumberService phoneNumberService;
    
	
	@CrossOrigin
	@RequestMapping(value ="/getResult/{phNum}" , method = RequestMethod.GET)
	public GetResponse getPhNumCombination(@PathVariable(value="phNum", required=true) String phNum){
		
		return phoneNumberService.generatePhoneNumbers(phNum);
		
	}

}
