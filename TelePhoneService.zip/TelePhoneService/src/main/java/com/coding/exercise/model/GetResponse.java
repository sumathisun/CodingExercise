package com.coding.exercise.model;

import java.util.ArrayList;
import java.util.List;

public class GetResponse{

  private List phNumList = new ArrayList<String>();


public void setPhNumList(List phNumList) {
	this.phNumList = phNumList;
}


public List getPhNumList() {
	return phNumList;
}    
  


}
