import { Component, SystemJsNgModuleLoader, OnInit } from '@angular/core';  
import { NgForm } from '@angular/forms';  

import { RestDataService } from './rest-data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { JsonPipe } from '@angular/common';




@Component({  
 selector: 'app-root',  
 templateUrl: './app.component.html',  
 styleUrls: ['./app.component.css']  
})  
export class AppComponent implements OnInit{  
 title = 'FormValidation';  
 areaCodePattern = "^[0-9]{3}$";  
 
 phNumberPattern = "^[0-9]{7}$";  
 
 isValidFormSubmitted = false;  
 user = new User();  

 items = [];
 pageOfItems: Array<any>;



 constructor(public rest:RestDataService, private route: ActivatedRoute, private router: Router) { }


 ngOnInit() {
   // an example array of 150 items to be paged
 //  this.items = Array(150).fill(0).map((x, i) => ({ id: (i + 1), name: `Item ${i + 1}`}));
}

onChangePage(pageOfItems: Array<any>) {
   // update current page of items
   //this.pageOfItems = pageOfItems;
}

 onClickSubmit(data) {  
     
     
   this.isValidFormSubmitted = true;  
   this.rest.getAlphaNumericResult(data.areaCode+data.phoneNumber).subscribe

   (data => {
      
      this.user.result = data.phNumList;
   
   console.log(data);
 });
}

resetForm(form)
{
   form.reset();
   this.isValidFormSubmitted=false;
}

    
}  




export class User {  
 phoneNumber ?: string;  
 areaCode ?:string;
 result ?:Array<String>;
}  

export class AlphaNumericResult{
   constructor( phNumList:string[]){

   }
}