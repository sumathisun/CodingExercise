import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { JwPaginationComponent } from 'jw-angular-pagination';

const appRoutes: Routes = [
  {
    path: 'alpha-numeric-result/:phNumber',
    component: AppComponent,
    data: { title: 'AlphaNumericResult' }
  }];

@NgModule({
  declarations: [
    AppComponent,
    
    
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
